TikTok Shop Fashion Intelligence - Docker demo (MADT8102)
=========================================================
What it does : runs the 5-stage data pipeline (Ingest -> Extract -> Transform -> Load -> Validate)
               over 10 monthly deliveries, incl. a data-quality block in March, entirely inside a container.
               No cloud account needed. Synthetic educational data (NOT real TikTok data).
Requirements : Docker (Docker Desktop, or Docker Engine on Linux).
Run          :
    docker build -t tiktok-shop-pipeline .
    docker run --rm tiktok-shop-pipeline
Options      :
    docker run --rm tiktok-shop-pipeline python docker/run_demo.py --months 3
Time         : about 1-2 minutes. Thai guide: docker/README_DOCKER_TH.md
Note         : the web dashboard (Vercel + Neon) is not part of this package because it needs cloud services.
